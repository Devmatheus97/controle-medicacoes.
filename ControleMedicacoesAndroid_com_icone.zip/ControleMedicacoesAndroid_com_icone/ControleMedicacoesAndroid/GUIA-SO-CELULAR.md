# Como gerar o APK usando somente o celular

Este projeto inclui uma automação do GitHub Actions para compilar o APK na nuvem. Você não precisa instalar Android Studio no celular. É necessário ter uma conta GitHub e conexão com a internet.

## Passos
1. Baixe e extraia este ZIP no celular usando o gerenciador de arquivos. O GitHub precisa receber os arquivos e pastas extraídos, não o ZIP como um único arquivo.
2. No navegador, entre em https://github.com e crie um repositório novo, por exemplo `controle-medicacoes-android`. Deixe-o **Private** se preferir manter o código privado.
3. Abra o repositório e use **Add file > Upload files**. Envie os arquivos e pastas que estão dentro da pasta `ControleMedicacoesAndroid` (incluindo a pasta oculta `.github`, se o seletor de arquivos mostrar arquivos ocultos). Faça o commit na branch `main`.
4. Abra a aba **Actions** do repositório. Se solicitado, habilite workflows.
5. Se a compilação não começar automaticamente após o envio, abra o workflow **Compilar APK Android** e toque em **Run workflow**.
6. Abra a execução mais recente. Aguarde o status verde **Success** e vá até **Artifacts** no fim da página. Baixe `controle-medicacoes-apk`.
7. Extraia o ZIP do artefato; dentro estará `app-debug.apk`. Toque nele para instalar. Talvez seja necessário permitir ao navegador/gerenciador de arquivos instalar apps desconhecidos.

## Observações importantes
- O layout móvel do GitHub pode dificultar o envio de muitas pastas. Se não conseguir incluir `.github/workflows/compilar-apk.yml`, o workflow não aparecerá. Use a opção de mostrar arquivos ocultos do gerenciador ou crie a pasta/arquivo pelo editor web do GitHub.
- APK de depuração é para instalação e teste, não é publicação assinada na Play Store.
- Depois de instalar, permita notificações e alarmes exatos nas configurações do Android. Teste os alertas com um horário próximo; economia de bateria do aparelho pode atrasá-los.
- Este app é um protótipo. Não dependa dele como único controle de medicamentos sem testar cuidadosamente os alertas e manter um registro alternativo.
