package br.com.controlemedicacoes

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import java.util.Calendar

class MedicationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("medId") ?: "med"
        val name = intent.getStringExtra("medName") ?: "Medicamento"
        val dose = intent.getStringExtra("medDose") ?: ""
        val time = intent.getStringExtra("medTime") ?: ""
        val notifId = (id + time).hashCode()
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Horário de medicação")
            .setContentText("$name${if (dose.isNotBlank()) " · $dose" else ""} · Horário: $time")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Confira a prescrição e registre a administração de $name. Horário programado: $time."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { NotificationManagerCompat.from(context).notify(notifId, notification) } catch (_: SecurityException) { }
        scheduleDaily(context, id, name, dose, time)
    }

    companion object {
        const val CHANNEL_ID = "medication_schedule"
        const val PREFS = "medication_alarm_prefs"
        const val MEDS_JSON = "medications_json"

        fun scheduleDaily(context: Context, id: String, name: String, dose: String, time: String) {
            val parts = time.split(":")
            if (parts.size != 2) return
            val hour = parts[0].toIntOrNull() ?: return
            val minute = parts[1].toIntOrNull() ?: return
            if (hour !in 0..23 || minute !in 0..59) return
            val intent = Intent(context, MedicationAlarmReceiver::class.java).apply {
                putExtra("medId", id); putExtra("medName", name)
                putExtra("medDose", dose); putExtra("medTime", time)
            }
            val requestCode = (id + "|" + time).hashCode()
            val pi = PendingIntent.getBroadcast(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pi)
                }
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pi)
            }
        }

        fun cancelAll(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val arr = try { JSONArray(prefs.getString(MEDS_JSON, "[]")) } catch (_: Exception) { JSONArray() }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            for (i in 0 until arr.length()) {
                val med = arr.optJSONObject(i) ?: continue
                val id = med.optString("id")
                val times = med.optJSONArray("times") ?: JSONArray()
                for (j in 0 until times.length()) {
                    val time = times.optString(j)
                    val intent = Intent(context, MedicationAlarmReceiver::class.java)
                    val pi = PendingIntent.getBroadcast(
                        context, (id + "|" + time).hashCode(), intent,
                        PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                    )
                    if (pi != null) am.cancel(pi)
                }
            }
        }

        fun rescheduleSaved(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val arr = try { JSONArray(prefs.getString(MEDS_JSON, "[]")) } catch (_: Exception) { JSONArray() }
            for (i in 0 until arr.length()) {
                val med = arr.optJSONObject(i) ?: continue
                if (!med.optBoolean("active", true)) continue
                val times = med.optJSONArray("times") ?: JSONArray()
                for (j in 0 until times.length()) {
                    scheduleDaily(context, med.optString("id"), med.optString("name", "Medicamento"), med.optString("dose", ""), times.optString(j))
                }
            }
        }
    }
}
