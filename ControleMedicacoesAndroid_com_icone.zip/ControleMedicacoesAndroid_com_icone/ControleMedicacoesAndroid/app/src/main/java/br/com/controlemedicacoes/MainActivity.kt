package br.com.controlemedicacoes

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) createNotificationChannel()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidMedicationBridge(this), "AndroidMedicationBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                MedicationAlarmReceiver.CHANNEL_ID,
                "Horários de medicação",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Lembretes dos horários cadastrados para os medicamentos"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    inner class AndroidMedicationBridge(private val context: Context) {
        @JavascriptInterface
        fun syncMedications(json: String) {
            try {
                val arr = JSONArray(json)
                val prefs = getSharedPreferences(MedicationAlarmReceiver.PREFS, Context.MODE_PRIVATE)
                prefs.edit().putString(MedicationAlarmReceiver.MEDS_JSON, arr.toString()).apply()
                MedicationAlarmReceiver.cancelAll(context)
                for (i in 0 until arr.length()) {
                    val med = arr.getJSONObject(i)
                    if (med.optBoolean("active", true)) {
                        val id = med.optString("id")
                        val name = med.optString("name", "Medicamento")
                        val dose = med.optString("dose", "")
                        val times = med.optJSONArray("times") ?: JSONArray()
                        for (j in 0 until times.length()) {
                            val time = times.optString(j)
                            MedicationAlarmReceiver.scheduleDaily(context, id, name, dose, time)
                        }
                    }
                }
            } catch (_: Exception) { }
        }

        @JavascriptInterface
        fun requestExactAlarmPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (!am.canScheduleExactAlarms()) {
                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                        data = Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                }
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }
    }
}
