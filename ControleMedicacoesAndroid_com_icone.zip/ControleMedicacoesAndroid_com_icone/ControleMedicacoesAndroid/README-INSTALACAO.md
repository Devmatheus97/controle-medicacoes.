# Controle de Medicações — projeto Android nativo

Este projeto encapsula a interface HTML do protótipo em um WebView e adiciona alarmes Android com `AlarmManager`, notificações locais e reagendamento após reiniciar o aparelho.

## Como gerar o APK
1. Instale Android Studio (versão atual) com Android SDK Platform 35.
2. Abra a pasta `ControleMedicacoesAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build APK(s)**.
5. O APK de teste costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
- O ambiente em que este pacote foi preparado não possui Android SDK nem Gradle instalados, então não foi possível compilar nem testar o APK aqui. O que segue é o projeto-fonte para compilar no Android Studio.
- No Android 13+, conceda a permissão de notificações.
- No Android 12+, o sistema pode exigir permissão para alarmes exatos. A implementação usa alarmes exatos quando permitido e um fallback menos preciso se a permissão for negada.
- Fabricantes podem limitar execução em segundo plano; confira as configurações de bateria do Android.
- A tela de usuário/senha do protótipo é um bloqueio local, não autenticação segura de servidor. Não use como segurança clínica em aparelho compartilhado.
- Este aplicativo é um registro auxiliar, não substitui prescrição ou orientação profissional. Teste primeiro com dados fictícios.
